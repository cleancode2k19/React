const Claim = artifacts.require("Claim");

contract("Claim", (accounts) => {
 let Claim;
 let expectedClaimer;

 before(async () => {
     Claim = await claim.deployed();
 });

 describe("Claiming a lottery and retrieving account addresses", async () => {
   before("Claim a lottery using accounts[0]", async () => {
     await Claim.claim(8, { from: accounts[0] });
     expectedClaimer = accounts[0];
   });
   
  it("can fetch the address of an owner by lottery id", async () => {
   const Claimer = await Claim.Claimer(8);
   assert.equal(Claimer, expectedClaimer, "The owner of the Claimed lottery should be the first account.");
  }); 
   
 it("can fetch the collection of all lottery owners' addresses", async () => {
   const Claimers = await Claim.getClaimers();
   assert.equal(Claimers[8], expectedClaimer, "The owner of the Claimed lottery should be in the collection.");
});
   
 });
});

