var Claim = artifacts.require("Claim");

module.exports = function(deployer) {
  deployer.deploy(Claim);
};
